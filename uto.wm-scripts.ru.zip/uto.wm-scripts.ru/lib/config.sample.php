<?php
$host = "localhost";
$user = ""; 
$pass = ""; 
$name = "";

$adminuser = "";
$adminpassword = "";
?>