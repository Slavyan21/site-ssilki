<form method="post" action="create.php" id="urlcreateform">


  <div class="input-append">
    <input class="span8 meela" nFocus="clearText(this)" id="urlbox" name="url" pladeholder="http://" type="text"><button class="btn btn-large btn-primary" type="submit" id="submit">Shorten!</button>
  </div>

  <div id="opt">

      <label class="optlabel" for="custom">Custom URL <span style="font-size:9px;"><em>(Optional)</em></span>:</label>
      <input class="meela_custom" type="text" id="custombox" name="custom" size="40" value="" />

  </div>


</form>